## Assignment 1 CPP
##### Author:
Harm Manders, 10677186

#### Instructions
`make run` creates executable `run.o` which runs code for assignment1   
`make test` creates executable `testCode.o` to run tests provided by assignment  
`make` runs all make commands

#### References
Inspiration to calculate days passed since 1900:
http://www.cplusplus.com/reference/ctime/mktime/   
Documentation non struct tm:
http://www.cplusplus.com/reference/ctime/tm/