## Assignment 1 CPP
##### Author:
Harm Manders, 10677186

#### Instructions

Use MyCompress to compress or decompress files   
`./MyCompress -h` for help file   
`./MyCompress <flag> [<input-file>] [<output-file>]`   
Can print to either file or cout.   
Can read from either file or cin.